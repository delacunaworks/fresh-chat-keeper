(function() {
  "use strict";
  const LEGACY_PREFIX_KEYS = [
    "flc_anon_token",
    "flc_filter_count",
    "flc_judge_cache",
    "flc_settings",
    "flc_stage2_usage"
  ];
  async function cleanupLegacyPrefixKeys() {
    const found = await chrome.storage.local.get([...LEGACY_PREFIX_KEYS]);
    const existingKeys = LEGACY_PREFIX_KEYS.filter((k) => k in found);
    if (existingKeys.length === 0) return 0;
    await chrome.storage.local.remove(existingKeys);
    console.log(
      `[FreshChatKeeper] Cleaned up ${existingKeys.length} legacy flc_* keys: ${existingKeys.join(", ")}`
    );
    return existingKeys.length;
  }
  chrome.runtime.onInstalled.addListener(() => {
    void cleanupLegacyPrefixKeys();
  });
  chrome.runtime.onStartup.addListener(() => {
    void cleanupLegacyPrefixKeys();
  });
})();
